# English Pop Quiz — Chrome Extension

Extension đồng hành cùng các trang học tiếng Anh:
- `tuhoctienganh.netlify.app` (ưu tiên)
- `tienganhtrunghoc.netlify.app`
- `tienganhphothong.netlify.app`
- `learning-word.netlify.app`

## Cách hoạt động

1. **Đồng bộ tự động**: Khi bạn mở một trong 4 website trên, extension tự đọc từ vựng (IndexedDB) và lưu vào storage riêng của nó.
2. **Học khi lướt web**: Khi bạn mở một trang web khác (youtube, facebook...), extension hiện 1 ô cửa sổ nhỏ hỏi 1 từ.
3. **Giãn cách 2 phút**: Không bao giờ hỏi nhiều hơn 1 lần trong 2 phút.
4. **2 hình thức ngẫu nhiên**:
   - **Trắc nghiệm**: chọn đúng từ tiếng Anh từ 4 phương án
   - **Gõ từ**: gõ lại từ tiếng Anh
   - *(Đã loại bỏ hình thức Nói để không phải xin quyền microphone trên mọi website)*
5. **Tùy chỉnh trong popup**:
   - **Số từ / phiên** (1–10, mặc định 1)
   - **Đúng mấy lần = thuộc** (1–5, mặc định 2)
6. **Thuật toán thuộc**: Đúng +1, sai -1. Đạt ngưỡng = thuộc, không hỏi lại.
6. **Ưu tiên phiên mới nhất**: Học hết phiên mới nhất mới sang phiên cũ hơn.
7. **Sai vẫn cho qua**: Không bao giờ chặn bạn vào trang.

## Cài đặt

1. Mở Chrome → `chrome://extensions/`
2. Bật **Developer mode** (góc trên phải)
3. Nhấn **Load unpacked** → chọn thư mục `extension/` này
4. Mở `tuhoctienganh.netlify.app` (hoặc domain bạn đang dùng) để đồng bộ dữ liệu
5. Xong! Chuyển sang tab bất kỳ và bắt đầu học.

## Bật / tắt

Nhấn icon extension trên thanh Chrome → gạt nút **Kích hoạt**.

## Thêm nguồn đồng bộ tùy chỉnh

Nếu bạn có website học khác cùng định dạng IndexedDB (`EnglishAppDB` với store `vocabulary`), bạn có thể thêm URL trong popup extension:

1. Mở popup extension
2. Nhập URL hoặc hostname vào ô "Nguồn đồng bộ tùy chỉnh" (vd: `mysite.com` hoặc `https://mysite.com/app`)
3. Nhấn **Thêm**
4. Mở trang đó — extension tự inject script đồng bộ

Các domain tùy chỉnh này cũng sẽ được **loại trừ** khỏi popup quiz (không bị hỏi khi đang học).

## Cấu trúc file

```
extension/
├── manifest.json       # Manifest V3 config
├── background.js       # Service worker: state, timing, word picking
├── sync.js             # Content script chạy trên 4 website — đọc IndexedDB
├── quiz.js             # Content script chạy trên trang khác — hiện overlay
├── overlay.css         # (empty — CSS nằm trong shadow DOM)
├── popup.html          # Giao diện nhấn icon
├── popup.js            # Logic popup (toggle + stats)
└── README.md
```

## Ghi chú kỹ thuật

- **Shadow DOM**: Overlay render trong closed shadow root → không bị CSS của trang web can thiệp.
- **Cross-origin IndexedDB**: Extension không đọc trực tiếp IDB của website từ tab khác. Thay vào đó, content script trên chính website đọc rồi gửi qua `chrome.runtime.sendMessage` vào `chrome.storage.local` của extension.
- **SPA navigation**: Bắt được cả điều hướng SPA qua `MutationObserver` theo dõi `location.href`.
- **Cooldown 2 phút**: Lưu ở `chrome.storage.local.lastAskedAt`, áp dụng toàn cục (không reset theo tab).
