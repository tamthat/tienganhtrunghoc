// Runs on every site except the 4 source websites. Pops a quiz overlay on navigation.
(function () {
    if (window.top !== window) return; // only in top frame
    if (window.__englishPopQuizLoaded) return;
    window.__englishPopQuizLoaded = true;

    let shownThisPage = false;
    let isCustomSource = false;

    chrome.storage.local.get('customHosts', ({ customHosts }) => {
        if (Array.isArray(customHosts) && customHosts.includes(location.hostname)) {
            isCustomSource = true;
        }
    });

    function tryShow() {
        if (shownThisPage || isCustomSource) return;
        chrome.runtime.sendMessage({ type: 'REQUEST_SESSION' }, (res) => {
            if (chrome.runtime.lastError) return;
            if (!res || !res.ok || !res.items || !res.items.length) return;
            shownThisPage = true;
            renderSession(res.items);
        });
    }

    // Show on page load, with a small delay so site settles
    setTimeout(tryShow, 800);

    // Handle SPA navigation
    let lastUrl = location.href;
    new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            shownThisPage = false;
            setTimeout(tryShow, 1000);
        }
    }).observe(document, { subtree: true, childList: true });

    // Periodic re-check: even without navigation, retry every 15s.
    // background.js enforces the 2-minute cooldown, so this will only actually
    // pop a quiz when the cooldown expires AND no overlay is currently shown.
    setInterval(() => {
        if (document.getElementById('english-pop-quiz-host')) return;
        shownThisPage = false;
        tryShow();
    }, 15000);
    // Also re-check when the tab regains focus (Chrome may have throttled timers
    // while the tab was in the background).
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && !document.getElementById('english-pop-quiz-host')) {
            shownThisPage = false;
            tryShow();
        }
    });

    function renderSession(items) {
        // If this tab becomes hidden, close the overlay. The pendingSession stays in
        // storage, so whichever tab the user switches TO will pick it up and show the
        // same question. The popup "follows" the user.
        const hideOnBlur = () => {
            if (document.visibilityState === 'hidden') {
                const h = document.getElementById('english-pop-quiz-host');
                if (h) h.remove();
                document.removeEventListener('visibilitychange', hideOnBlur);
            }
        };
        document.addEventListener('visibilitychange', hideOnBlur);

        const host = document.createElement('div');
        host.id = 'english-pop-quiz-host';
        host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;top:0;left:0;width:0;height:0;';
        const root = host.attachShadow({ mode: 'closed' });
        (document.body || document.documentElement).appendChild(host);

        const style = document.createElement('style');
        style.textContent = CSS;
        root.appendChild(style);

        const backdrop = document.createElement('div');
        backdrop.className = 'epq-backdrop';
        root.appendChild(backdrop);

        // Block host-page keyboard shortcuts while overlay is open.
        // Use BUBBLE phase so events still reach the input first, then we stop them
        // from propagating up to window/document where the host site listens.
        ['keydown', 'keyup', 'keypress'].forEach(evt => {
            backdrop.addEventListener(evt, (e) => e.stopPropagation(), false);
        });

        const panel = document.createElement('div');
        panel.className = 'epq-panel';
        backdrop.appendChild(panel);

        let index = 0;
        const close = () => host.remove();

        const renderItem = () => {
            if (index >= items.length) { close(); return; }
            const { mode, word, options } = items[index];
            renderOne(panel, mode, word, options, () => {
                index++;
                renderItem();
            });
        };
        renderItem();
    }

    function renderOne(panel, mode, word, options, onDone) {
        const label = mode === 'quiz' ? '🎯 Trắc nghiệm' : mode === 'typing' ? '⌨️ Gõ từ' : '🎤 Nói từ';
        const pos = word.pos ? `<span class="epq-pos">(${escapeHtml(word.pos)})</span>` : '';

        panel.innerHTML = `
      <div class="epq-header">
        <div class="epq-mode">${label}</div>
        <button class="epq-skip" title="Bỏ qua">✕</button>
      </div>
      <div class="epq-hint">Nghĩa tiếng Việt:</div>
      <div class="epq-meaning">${escapeHtml(word.meaning)} ${pos}</div>
      <div class="epq-body"></div>
      <div class="epq-result" style="display:none"></div>
      <div class="epq-footer">
        <button class="epq-continue" style="display:none">Tiếp tục →</button>
      </div>
    `;

        const body = panel.querySelector('.epq-body');
        const resultEl = panel.querySelector('.epq-result');
        const continueBtn = panel.querySelector('.epq-continue');
        const skipBtn = panel.querySelector('.epq-skip');

        let resultShown = false;
        let advanceArmed = false;
        function finish(correct) {
            if (resultShown) return;
            resultShown = true;
            // Don't arm the advance-on-Enter until the key is RELEASED.
            // This prevents the same Enter (auto-repeat or long press) from immediately
            // triggering onDone() right after finish().
            advanceArmed = false;
            chrome.runtime.sendMessage({ type: 'RECORD_RESULT', wordId: word.id, correct }, () => { });
            resultEl.style.display = 'block';
            resultEl.innerHTML = correct
                ? `<div class="epq-ok">✅ Chính xác!</div><div class="epq-answer">${escapeHtml(word.word)} ${word.phonetic ? `<span class="epq-phon">${escapeHtml(word.phonetic)}</span>` : ''}</div>`
                : `<div class="epq-bad">❌ Chưa đúng. Đáp án:</div><div class="epq-answer">${escapeHtml(word.word)} ${word.phonetic ? `<span class="epq-phon">${escapeHtml(word.phonetic)}</span>` : ''}</div>`;
            continueBtn.style.display = 'inline-block';
            // Disable inputs but DON'T focus the continue button — that causes the same
            // Enter keypress to bubble into the button and trigger click immediately.
            // Instead, refocus the (now-disabled) input area so a fresh Enter is needed.
            body.querySelectorAll('button,input').forEach(el => el.disabled = true);
        }

        continueBtn.addEventListener('click', onDone);

        // After result is shown, a fresh Enter advances to next item.
        // The 300ms arm delay ensures the same Enter that triggered check() can't
        // immediately advance.
        const advanceKey = (e) => {
            if (!resultShown || !advanceArmed) return;
            if (e.key === 'Enter') {
                e.preventDefault();
                e.stopPropagation();
                document.removeEventListener('keydown', advanceKey, true);
                document.removeEventListener('keyup', armOnKeyup, true);
                onDone();
            }
        };
        // Arm advance only after Enter is physically released post-finish().
        // Prevents auto-repeat or the same Enter from check() triggering advance.
        const armOnKeyup = (e) => {
            if (resultShown && e.key === 'Enter') {
                advanceArmed = true;
                document.removeEventListener('keyup', armOnKeyup, true);
            }
        };
        document.addEventListener('keydown', advanceKey, true);
        document.addEventListener('keyup', armOnKeyup, true);
        skipBtn.addEventListener('click', () => {
            // Notify background to clear pending + start cooldown
            chrome.runtime.sendMessage({ type: 'SKIP_SESSION' }, () => { });
            const h = document.getElementById('english-pop-quiz-host');
            if (h) h.remove();
            document.removeEventListener('keydown', advanceKey, true);
        });

        // Build mode-specific body
        if (mode === 'quiz') {
            const grid = document.createElement('div');
            grid.className = 'epq-options';
            options.forEach(opt => {
                const btn = document.createElement('button');
                btn.className = 'epq-option';
                btn.textContent = opt;
                btn.addEventListener('click', () => {
                    const ok = opt.toLowerCase().trim() === word.word.toLowerCase().trim();
                    if (ok) btn.classList.add('epq-correct');
                    else {
                        btn.classList.add('epq-wrong');
                        // Highlight correct one
                        grid.querySelectorAll('.epq-option').forEach(b => {
                            if (b.textContent.toLowerCase().trim() === word.word.toLowerCase().trim()) b.classList.add('epq-correct');
                        });
                    }
                    finish(ok);
                });
                grid.appendChild(btn);
            });
            body.appendChild(grid);
        } else if (mode === 'typing') {
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'epq-input';
            input.placeholder = 'Gõ từ tiếng Anh...';
            input.autocomplete = 'off';
            input.spellcheck = false;
            const submit = document.createElement('button');
            submit.className = 'epq-submit';
            submit.textContent = 'Kiểm tra';
            const wrap = document.createElement('div');
            wrap.className = 'epq-input-row';
            wrap.appendChild(input);
            wrap.appendChild(submit);
            body.appendChild(wrap);
            setTimeout(() => input.focus(), 100);

            const check = () => {
                const ok = input.value.toLowerCase().trim() === word.word.toLowerCase().trim();
                if (ok) input.classList.add('epq-correct');
                else input.classList.add('epq-wrong');
                finish(ok);
            };
            submit.addEventListener('click', check);
            // Stop ALL keyboard events from bubbling to the host page
            // (prevents site shortcuts like YouTube's 'p', 'k', 'f', '/' from firing)
            const stopKey = (e) => {
                e.stopPropagation();
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (!resultShown) check();
                }
            };
            input.addEventListener('keydown', stopKey);
            input.addEventListener('keyup', (e) => {
                e.stopPropagation();
                if (e.key === 'Enter') e.preventDefault();
            });
            input.addEventListener('keypress', (e) => {
                e.stopPropagation();
                if (e.key === 'Enter') e.preventDefault();
            });
        }

        function escapeHtml(s) {
            return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
        }
    }

    function escapeHtml(s) {
        return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    // CSS injected into shadow root
    const CSS = `
:host, * { box-sizing: border-box; }
.epq-backdrop {
  position: fixed; inset: 0;
  background: rgba(8, 10, 20, 0.78);
  backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center;
  font-family: -apple-system, Segoe UI, Roboto, sans-serif;
  animation: epq-fade 0.25s ease;
}
@keyframes epq-fade { from{opacity:0} to{opacity:1} }
.epq-panel {
  background: linear-gradient(145deg, #1a1d2e, #0f1220);
  color: #e2e8f0;
  border: 1px solid rgba(139, 92, 246, 0.35);
  border-radius: 16px;
  padding: 1.6rem 1.8rem;
  width: 92%;
  max-width: 520px;
  box-shadow: 0 20px 60px rgba(139, 92, 246, 0.25), 0 0 0 1px rgba(255,255,255,0.04);
  animation: epq-pop 0.35s cubic-bezier(.2,.9,.3,1.3);
}
@keyframes epq-pop { from{transform:scale(.9);opacity:0} to{transform:scale(1);opacity:1} }
.epq-header { display:flex; align-items:center; justify-content:space-between; margin-bottom: 0.8rem; }
.epq-mode { font-size: 0.95rem; font-weight: 600; color: #a78bfa; letter-spacing: 0.02em; }
.epq-skip {
  background: transparent; border: none; color: #64748b; font-size: 1.2rem; cursor: pointer;
  width: 28px; height: 28px; border-radius: 50%; transition: all 0.2s;
}
.epq-skip:hover { background: rgba(255,255,255,0.08); color: #e2e8f0; }
.epq-hint { font-size: 0.78rem; color: #64748b; margin-bottom: 0.3rem; text-transform: uppercase; letter-spacing: 0.08em; }
.epq-meaning { font-size: 1.35rem; font-weight: 600; color: #fbbf24; margin-bottom: 1.4rem; line-height: 1.35; }
.epq-pos { font-size: 0.85rem; color: #94a3b8; font-style: italic; font-weight: 400; }
.epq-body { margin-bottom: 1rem; }
.epq-options { display: grid; grid-template-columns: 1fr 1fr; gap: 0.7rem; }
.epq-option {
  padding: 0.9rem 1rem; border-radius: 10px;
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
  color: #e2e8f0; font-size: 1rem; cursor: pointer; transition: all 0.2s;
  text-align: center;
}
.epq-option:hover:not(:disabled) { background: rgba(139,92,246,0.15); border-color: #a78bfa; transform: translateY(-1px); }
.epq-option:disabled { cursor: default; opacity: 0.85; }
.epq-option.epq-correct { background: rgba(74,222,128,0.15); border-color: #4ade80; color: #4ade80; }
.epq-option.epq-wrong { background: rgba(248,113,113,0.15); border-color: #f87171; color: #f87171; }
.epq-input-row { display: flex; gap: 0.5rem; }
.epq-input {
  flex: 1; padding: 0.9rem 1rem; border-radius: 10px;
  background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.12);
  color: #e2e8f0; font-size: 1.1rem; outline: none; transition: all 0.2s;
}
.epq-input:focus { border-color: #a78bfa; background: rgba(139,92,246,0.08); }
.epq-input.epq-correct { border-color: #4ade80; background: rgba(74,222,128,0.08); }
.epq-input.epq-wrong { border-color: #f87171; background: rgba(248,113,113,0.08); }
.epq-submit, .epq-continue {
  padding: 0.9rem 1.4rem; border-radius: 10px; border: none; cursor: pointer;
  background: linear-gradient(135deg, #8b5cf6, #6366f1); color: white;
  font-size: 0.95rem; font-weight: 600; transition: all 0.2s;
}
.epq-submit:hover, .epq-continue:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(139,92,246,0.4); }
.epq-mic {
  width: 100%; padding: 1.2rem; border-radius: 12px; cursor: pointer;
  background: linear-gradient(135deg, rgba(232,121,249,0.15), rgba(139,92,246,0.15));
  border: 1px solid rgba(232,121,249,0.35); color: #e879f9; font-size: 1.05rem; font-weight: 600;
  transition: all 0.2s;
}
.epq-mic:hover { background: rgba(232,121,249,0.2); }
.epq-heard { margin-top: 0.7rem; font-size: 0.95rem; color: #94a3b8; min-height: 1.2rem; font-style: italic; text-align: center; }
.epq-warn { color: #fbbf24; font-size: 0.9rem; text-align: center; padding: 0.5rem; }
.epq-result { padding: 0.9rem 1rem; border-radius: 10px; background: rgba(255,255,255,0.03); margin-bottom: 1rem; text-align: center; }
.epq-ok { color: #4ade80; font-weight: 600; margin-bottom: 0.4rem; }
.epq-bad { color: #f87171; font-weight: 600; margin-bottom: 0.4rem; }
.epq-answer { font-size: 1.3rem; font-weight: 700; color: #e2e8f0; }
.epq-phon { font-size: 0.95rem; color: #a78bfa; font-weight: 400; font-style: italic; margin-left: 0.5rem; }
.epq-footer { text-align: right; }
`;
})();
