const toggle = document.getElementById('toggle');
const totalEl = document.getElementById('total');
const masteredEl = document.getElementById('mastered');
const barEl = document.getElementById('bar');
const lastEl = document.getElementById('last');
const hintEl = document.getElementById('hint');
const userRow = document.getElementById('userRow');
const userSelect = document.getElementById('userSelect');
const wordsInput = document.getElementById('wordsInput');
const masterInput = document.getElementById('masterInput');
const hostListEl = document.getElementById('hostList');
const hostInput = document.getElementById('hostInput');
const addBtn = document.getElementById('addBtn');
const grabBtn = document.getElementById('grabBtn');
const msgEl = document.getElementById('msg');

function fmtAgo(ts) {
    if (!ts) return '—';
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 60) return `${s}s trước`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m} phút trước`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h} giờ trước`;
    return `${Math.floor(h / 24)} ngày trước`;
}

function refresh() {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (s) => {
        if (!s) return;
        toggle.classList.toggle('on', !!s.enabled);
        totalEl.textContent = s.totalWords;
        masteredEl.textContent = s.masteredWords;
        const pct = s.totalWords > 0 ? Math.round((s.masteredWords / s.totalWords) * 100) : 0;
        barEl.style.width = pct + '%';
        lastEl.textContent = fmtAgo(s.lastAskedAt);
        if (document.activeElement !== wordsInput) wordsInput.value = s.wordsPerSession || 2;
        if (document.activeElement !== masterInput) masterInput.value = s.masterScore || 2;

        // User picker
        const users = s.usersList || [];
        if (users.length > 0) {
            userRow.style.display = 'flex';
            if (userSelect.dataset.signature !== JSON.stringify(users.map(u => u.userCode))) {
                userSelect.innerHTML = '';
                users.forEach(u => {
                    const opt = document.createElement('option');
                    opt.value = u.userCode;
                    opt.textContent = `${u.username} (${u.wordCount})`;
                    userSelect.appendChild(opt);
                });
                userSelect.dataset.signature = JSON.stringify(users.map(u => u.userCode));
            }
            if (s.activeUser) userSelect.value = s.activeUser;
        } else {
            userRow.style.display = 'none';
        }

        if (s.totalWords === 0) {
            hintEl.textContent = 'Chưa có dữ liệu. Mở tuhoctienganh.netlify.app hoặc thêm URL tùy chỉnh.';
        } else {
            const hosts = Object.keys(s.syncMeta || {});
            hintEl.textContent = hosts.length > 0
                ? `Đã đồng bộ từ: ${hosts.join(', ')}`
                : 'Sẵn sàng. Chuyển tab để bắt đầu học!';
        }
    });
    renderCustomHosts();
}

function renderCustomHosts() {
    chrome.storage.local.get('customHosts', ({ customHosts }) => {
        const list = customHosts || [];
        hostListEl.innerHTML = '';
        if (list.length === 0) {
            hostListEl.innerHTML = '<div style="font-size:0.72rem;color:#64748b;padding:0.3rem 0">Chưa có. 4 domain mặc định luôn hoạt động.</div>';
            return;
        }
        list.forEach(h => {
            const row = document.createElement('div');
            row.className = 'host-row';
            row.innerHTML = `<span title="${h}">${h}</span><button data-host="${h}">✕</button>`;
            row.querySelector('button').addEventListener('click', () => {
                chrome.runtime.sendMessage({ type: 'REMOVE_CUSTOM_HOST', host: h }, renderCustomHosts);
            });
            hostListEl.appendChild(row);
        });
    });
}

toggle.addEventListener('click', () => {
    const next = !toggle.classList.contains('on');
    chrome.runtime.sendMessage({ type: 'TOGGLE_ENABLED', value: next }, refresh);
});

function showMsg(text, ok) {
    msgEl.textContent = text;
    msgEl.className = 'msg ' + (ok ? 'ok' : 'err');
    setTimeout(() => { msgEl.textContent = ''; msgEl.className = 'msg'; }, 3000);
}

addBtn.addEventListener('click', () => {
    const url = hostInput.value.trim();
    if (!url) return;
    chrome.runtime.sendMessage({ type: 'ADD_CUSTOM_HOST', url }, (res) => {
        if (!res) return;
        if (res.ok) {
            hostInput.value = '';
            showMsg(`✓ Đã thêm ${res.host}. Mở trang đó để đồng bộ.`, true);
            renderCustomHosts();
        } else {
            showMsg('✗ ' + (res.error || 'Lỗi'), false);
        }
    });
});

hostInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') addBtn.click(); });

grabBtn.addEventListener('click', async () => {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id || !tab.url) { showMsg('✗ Không tìm thấy tab hiện tại', false); return; }
        let host;
        try { host = new URL(tab.url).hostname; } catch { host = ''; }
        if (!host || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) {
            showMsg('✗ Tab hiện tại không hợp lệ. Mở trang web học của bạn rồi thử lại.', false);
            return;
        }
        showMsg('⏳ Đang kiểm tra trang...', true);

        // Check EnglishAppDB exists on current tab
        const check = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => new Promise(resolve => {
                try {
                    const req = indexedDB.open('EnglishAppDB');
                    req.onsuccess = () => {
                        const db = req.result;
                        const has = db.objectStoreNames.contains('vocabulary');
                        db.close();
                        resolve(has);
                    };
                    req.onerror = () => resolve(false);
                    req.onblocked = () => resolve(false);
                    setTimeout(() => resolve(false), 2000);
                } catch { resolve(false); }
            }),
        });
        const ok = check && check[0] && check[0].result;
        if (!ok) {
            showMsg('✗ Trang hiện tại không phải web học tiếng Anh. Hãy chuyển sang trang web học của bạn rồi thử lại.', false);
            return;
        }

        // Register host as custom (so future visits auto-sync)
        await new Promise(r => chrome.runtime.sendMessage({ type: 'ADD_CUSTOM_HOST', url: tab.url }, r));

        // Inject sync.js to actually pull data now
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['sync.js'] });
        showMsg(`✓ Đang đồng bộ từ ${host}...`, true);
        setTimeout(refresh, 2500);
    } catch (e) {
        showMsg('✗ Lỗi: ' + (e.message || e), false);
    }
});

wordsInput.addEventListener('change', () => {
    chrome.runtime.sendMessage({ type: 'SET_OPTION', key: 'wordsPerSession', value: wordsInput.value }, (res) => {
        if (res?.ok) showMsg(`✓ Mỗi phiên ${res.value} từ`, true);
    });
});
masterInput.addEventListener('change', () => {
    chrome.runtime.sendMessage({ type: 'SET_OPTION', key: 'masterScore', value: masterInput.value }, (res) => {
        if (res?.ok) showMsg(`✓ Đúng ${res.value} lần = thuộc`, true);
    });
});

userSelect.addEventListener('change', () => {
    chrome.runtime.sendMessage({ type: 'SET_ACTIVE_USER', userCode: userSelect.value }, (res) => {
        if (res && res.ok) { showMsg('✓ Đã đổi người học', true); refresh(); }
        else showMsg('✗ ' + (res?.error || 'Lỗi'), false);
    });
});

refresh();
setInterval(refresh, 3000);
