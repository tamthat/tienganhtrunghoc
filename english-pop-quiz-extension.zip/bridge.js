// Bridge content script: lets the EnglishApp web page ask the extension to do
// things a plain web page cannot (fetching quizlet.com is blocked by CORS).
// Page -> window.postMessage -> here -> chrome.runtime -> background.js
(function () {
    const REQ = 'ENGLISH_APP_EXT_REQUEST';
    const RES = 'ENGLISH_APP_EXT_RESPONSE';

    function reply(requestId, payload) {
        window.postMessage(Object.assign({ source: RES, requestId }, payload), '*');
    }

    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        const msg = event.data;
        if (!msg || msg.source !== REQ || !msg.requestId) return;

        if (msg.type === 'PING') {
            let version = '';
            try { version = chrome.runtime.getManifest().version; } catch (e) { /* ignore */ }
            reply(msg.requestId, { ok: true, version });
            return;
        }

        if (msg.type === 'SCRAPE_QUIZLET') {
            try {
                chrome.runtime.sendMessage({ type: 'SCRAPE_QUIZLET', url: msg.url }, (res) => {
                    if (chrome.runtime.lastError) {
                        reply(msg.requestId, { ok: false, error: chrome.runtime.lastError.message });
                        return;
                    }
                    reply(msg.requestId, res || { ok: false, error: 'Extension không phản hồi' });
                });
            } catch (e) {
                reply(msg.requestId, { ok: false, error: String((e && e.message) || e) });
            }
        }
    });

    // Announce presence for pages whose listener attaches before this script runs.
    window.postMessage({ source: RES, type: 'READY' }, '*');
})();
