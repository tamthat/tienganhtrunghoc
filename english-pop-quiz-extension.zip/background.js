// Service worker: receives vocab sync, tracks timing, serves word picks.
const PRIORITY_HOST = 'tuhoctienganh.netlify.app';
const MIN_INTERVAL_MS = 2 * 60 * 1000; // 2 minutes

chrome.runtime.onInstalled.addListener(async () => {
    const current = await chrome.storage.local.get(['enabled', 'progress', 'lastAskedAt', 'customHosts', 'wordsPerSession', 'masterScore']);
    if (current.enabled === undefined) await chrome.storage.local.set({ enabled: true });
    if (!current.progress) await chrome.storage.local.set({ progress: {} });
    if (!current.lastAskedAt) await chrome.storage.local.set({ lastAskedAt: 0 });
    if (!current.customHosts) await chrome.storage.local.set({ customHosts: [] });
    if (!current.wordsPerSession) await chrome.storage.local.set({ wordsPerSession: 2 });
    if (!current.masterScore) await chrome.storage.local.set({ masterScore: 2 });
    await reregisterCustomSyncs();
    await refreshBadge();
});

chrome.runtime.onStartup.addListener(async () => {
    await reregisterCustomSyncs();
    await refreshBadge();
});

async function refreshBadge() {
    const { enabled } = await chrome.storage.local.get('enabled');
    const on = enabled !== false;
    try {
        await chrome.action.setBadgeText({ text: on ? 'ON' : 'OFF' });
        await chrome.action.setBadgeBackgroundColor({ color: on ? '#22c55e' : '#78350f' });
        if (chrome.action.setBadgeTextColor) {
            await chrome.action.setBadgeTextColor({ color: '#ffffff' });
        }
        await chrome.action.setTitle({ title: on ? 'English Pop Quiz — Đang bật' : 'English Pop Quiz — Đã tắt' });
    } catch (e) { /* ignore */ }
}

async function reregisterCustomSyncs() {
    try {
        const { customHosts } = await chrome.storage.local.get('customHosts');
        const existing = await chrome.scripting.getRegisteredContentScripts({ ids: ['custom-sync'] }).catch(() => []);
        if (existing.length > 0) {
            await chrome.scripting.unregisterContentScripts({ ids: ['custom-sync'] });
        }
        if (!customHosts || customHosts.length === 0) return;
        const matches = customHosts.map(h => `*://${h}/*`);
        await chrome.scripting.registerContentScripts([{
            id: 'custom-sync',
            matches,
            js: ['sync.js'],
            runAt: 'document_idle',
        }]);
    } catch (e) {
        console.warn('[EnglishPopQuiz] registerContentScripts failed:', e);
    }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'SYNC_VOCAB') {
        handleSync(msg).then(() => sendResponse({ ok: true }));
        return true;
    }
    if (msg.type === 'REQUEST_SESSION') {
        pickSession().then(data => sendResponse(data));
        return true;
    }
    if (msg.type === 'RECORD_RESULT') {
        recordResult(msg.wordId, msg.correct).then(() => sendResponse({ ok: true }));
        return true;
    }
    if (msg.type === 'SET_OPTION') {
        setOption(msg.key, msg.value).then(r => sendResponse(r));
        return true;
    }
    if (msg.type === 'SKIP_SESSION') {
        // User dismissed popup. Clear pending + start cooldown from now.
        chrome.storage.local.set({ pendingSession: null, lastAskedAt: Date.now() })
            .then(() => sendResponse({ ok: true }));
        return true;
    }
    if (msg.type === 'GET_STATUS') {
        getStatus().then(s => sendResponse(s));
        return true;
    }
    if (msg.type === 'TOGGLE_ENABLED') {
        chrome.storage.local.set({ enabled: !!msg.value })
            .then(() => refreshBadge())
            .then(() => sendResponse({ ok: true }));
        return true;
    }
    if (msg.type === 'ADD_CUSTOM_HOST') {
        addCustomHost(msg.url).then(r => sendResponse(r));
        return true;
    }
    if (msg.type === 'REMOVE_CUSTOM_HOST') {
        removeCustomHost(msg.host).then(r => sendResponse(r));
        return true;
    }
    if (msg.type === 'SET_ACTIVE_USER') {
        setActiveUser(msg.userCode).then(r => sendResponse(r));
        return true;
    }
});

async function setActiveUser(userCode) {
    const { vocab } = await chrome.storage.local.get('vocab');
    if (!vocab || !vocab[userCode]) return { ok: false, error: 'User không tồn tại' };
    await chrome.storage.local.set({ activeUser: userCode, userPinned: userCode });
    return { ok: true };
}

async function addCustomHost(rawUrl) {
    try {
        let host;
        try { host = new URL(rawUrl.trim()).hostname; } catch { host = rawUrl.trim().replace(/^https?:\/\//, '').split('/')[0]; }
        if (!host) return { ok: false, error: 'URL không hợp lệ' };
        const { customHosts } = await chrome.storage.local.get('customHosts');
        const list = customHosts || [];
        if (list.includes(host)) return { ok: false, error: 'Đã có trong danh sách' };
        list.push(host);
        await chrome.storage.local.set({ customHosts: list });
        await reregisterCustomSyncs();
        return { ok: true, host };
    } catch (e) {
        return { ok: false, error: String(e.message || e) };
    }
}

async function removeCustomHost(host) {
    const { customHosts } = await chrome.storage.local.get('customHosts');
    const list = (customHosts || []).filter(h => h !== host);
    await chrome.storage.local.set({ customHosts: list });
    await reregisterCustomSyncs();
    return { ok: true };
}

async function handleSync(msg) {
    const store = await chrome.storage.local.get(['vocab', 'activeUser', 'syncMeta', 'usersList', 'userPinned']);
    const meta = store.syncMeta || {};
    const existing = store.vocab || {};

    const isPriority = msg.host === PRIORITY_HOST;
    const priorityMeta = meta[PRIORITY_HOST];
    const priorityHasData = priorityMeta && priorityMeta.syncedAt && Object.keys(existing).length > 0;

    if (!isPriority && priorityHasData) {
        meta[msg.host] = { syncedAt: msg.syncedAt };
        await chrome.storage.local.set({ syncMeta: meta });
        return;
    }

    // Accept: merge all users from this sync
    const merged = { ...existing };
    Object.keys(msg.vocabMap || {}).forEach(uc => { merged[uc] = msg.vocabMap[uc]; });

    meta[msg.host] = { syncedAt: msg.syncedAt };

    // Pick active user: keep user-pinned choice if still valid; else the newest-latest
    let activeUser = store.activeUser;
    const validCodes = Object.keys(merged);
    if (store.userPinned && validCodes.includes(store.userPinned)) {
        activeUser = store.userPinned;
    } else if (!activeUser || !validCodes.includes(activeUser)) {
        // Pick from usersList (newest latest first)
        const sorted = (msg.usersList || []).slice().sort((a, b) => b.latest - a.latest);
        activeUser = sorted[0]?.userCode || validCodes[0];
    }

    await chrome.storage.local.set({
        vocab: merged,
        activeUser,
        syncMeta: meta,
        usersList: msg.usersList || [],
    });
}

async function getWordPool() {
    const { vocab, activeUser, progress } = await chrome.storage.local.get(['vocab', 'activeUser', 'progress']);
    if (!vocab || !activeUser) return { pool: [], progress: progress || {} };
    const words = vocab[activeUser] || [];
    return { pool: words, progress: progress || {} };
}

function groupBySession(words) {
    const groups = {};
    words.forEach(w => {
        if (!groups[w.sessionName]) groups[w.sessionName] = { name: w.sessionName, latest: 0, words: [] };
        groups[w.sessionName].words.push(w);
        if (w.sessionCreatedAt > groups[w.sessionName].latest) groups[w.sessionName].latest = w.sessionCreatedAt;
    });
    return Object.values(groups).sort((a, b) => b.latest - a.latest);
}

const PENDING_TIMEOUT_MS = 3 * 60 * 1000; // 3 min safety: orphaned popup auto-clears

async function pickSession() {
    const { enabled, lastAskedAt, wordsPerSession, masterScore, pendingSession } = await chrome.storage.local.get(
        ['enabled', 'lastAskedAt', 'wordsPerSession', 'masterScore', 'pendingSession']
    );
    if (!enabled) return { ok: false, reason: 'disabled' };

    const now = Date.now();

    // If there's an existing pending session with items, REUSE it.
    // This lets the popup "follow" the user: tab A shows it, user switches to tab B
    // without answering → tab B gets the same question.
    if (pendingSession && pendingSession.items && pendingSession.startedAt) {
        const age = now - pendingSession.startedAt;
        if (age < PENDING_TIMEOUT_MS) {
            return { ok: true, items: pendingSession.items, resumed: true };
        }
        // Too old → clear and continue to build a fresh one
        await chrome.storage.local.set({ pendingSession: null });
    }

    // Cooldown only counts time since the user actually answered something.
    if (now - (lastAskedAt || 0) < MIN_INTERVAL_MS) {
        return { ok: false, reason: 'cooldown', waitMs: MIN_INTERVAL_MS - (now - (lastAskedAt || 0)) };
    }

    const { pool, progress } = await getWordPool();
    if (!pool.length) return { ok: false, reason: 'no-vocab' };

    const MASTER = Math.max(1, masterScore || 2);
    const N = Math.max(1, Math.min(10, wordsPerSession || 2));

    // === Spaced repetition: 50% newest / 30% ~3 days old / 20% ~7-10 days old ===
    const sessions = groupBySession(pool);
    const DAY = 86400000;
    const nowMs = Date.now();

    // Helper: collect unmastered words from a list, sorted by least-recently-asked
    const filterUnmastered = (words) => {
        const list = words.filter(w => {
            const p = progress[w.id];
            return !p || (p.score || 0) < MASTER;
        });
        list.sort((a, b) => {
            const pa = progress[a.id] || {};
            const pb = progress[b.id] || {};
            return (pa.lastAskedAt || 0) - (pb.lastAskedAt || 0);
        });
        return list;
    };

    // Bucket sessions by age relative to their latest word's createdAt
    const newestBucket = [];   // session #0 (the most recent)
    const midBucket = [];      // sessions 2-4 days old
    const oldBucket = [];      // sessions 7-10 days old
    sessions.forEach((sess, idx) => {
        const ageDays = (nowMs - sess.latest) / DAY;
        if (idx === 0) newestBucket.push(...sess.words);
        if (ageDays >= 2 && ageDays <= 4) midBucket.push(...sess.words);
        if (ageDays >= 7 && ageDays <= 10) oldBucket.push(...sess.words);
    });

    // Allocation
    const want = {
        newest: Math.round(N * 0.5),
        mid: Math.round(N * 0.3),
        old: N - Math.round(N * 0.5) - Math.round(N * 0.3),
    };
    if (want.newest < 1 && N >= 1) want.newest = 1;

    const take = (bucket, count) => filterUnmastered(bucket).slice(0, count);

    let collected = [];
    collected.push(...take(newestBucket, want.newest));
    collected.push(...take(midBucket, want.mid));
    collected.push(...take(oldBucket, want.old));

    // De-duplicate (a word may appear in multiple buckets if user has weird timing)
    const seen = new Set();
    collected = collected.filter(w => { if (seen.has(w.id)) return false; seen.add(w.id); return true; });

    // Fallback: if buckets didn't fill N (e.g. no mid/old sessions yet), top up from any unmastered
    if (collected.length < N) {
        const allUnmastered = filterUnmastered(pool).filter(w => !seen.has(w.id));
        for (const w of allUnmastered) {
            if (collected.length >= N) break;
            collected.push(w);
            seen.add(w.id);
        }
    }

    if (!collected.length) return { ok: false, reason: 'all-mastered' };

    // Shuffle so the order isn't always newest → mid → old
    for (let i = collected.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [collected[i], collected[j]] = [collected[j], collected[i]];
    }

    const modes = ['quiz', 'typing'];
    const items = collected.map(word => {
        const mode = modes[Math.floor(Math.random() * modes.length)];
        let options = null;
        if (mode === 'quiz') {
            const others = pool.filter(w => w.id !== word.id);
            for (let i = others.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [others[i], others[j]] = [others[j], others[i]];
            }
            const distractors = others.slice(0, 3).map(w => w.word);
            options = [word.word, ...distractors];
            for (let i = options.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [options[i], options[j]] = [options[j], options[i]];
            }
        }
        return { mode, word, options };
    });

    // Store items so any tab can resume the same question if user switches tabs.
    await chrome.storage.local.set({ pendingSession: { startedAt: Date.now(), items } });

    return { ok: true, items };
}

async function setOption(key, value) {
    const allowed = ['wordsPerSession', 'masterScore'];
    if (!allowed.includes(key)) return { ok: false, error: 'Invalid option' };
    const v = Math.max(1, Math.min(key === 'wordsPerSession' ? 10 : 5, parseInt(value) || 1));
    await chrome.storage.local.set({ [key]: v });
    return { ok: true, value: v };
}

async function recordResult(wordId, correct) {
    const { progress, masterScore } = await chrome.storage.local.get(['progress', 'masterScore']);
    const MAX = Math.max(1, masterScore || 2);
    const p = progress || {};
    const cur = p[wordId] || { score: 0, asked: 0, wrong: 0, lastAskedAt: 0 };
    cur.asked += 1;
    cur.lastAskedAt = Date.now();
    if (correct) {
        cur.score = Math.min(MAX, (cur.score || 0) + 1);
    } else {
        cur.wrong += 1;
        cur.score = Math.max(0, (cur.score || 0) - 1);
    }
    p[wordId] = cur;
    // Clear pending session: user has answered, cooldown can start counting now.
    await chrome.storage.local.set({ progress: p, lastAskedAt: Date.now(), pendingSession: null });
}

async function getStatus() {
    const { enabled, vocab, activeUser, progress, lastAskedAt, syncMeta, usersList, wordsPerSession, masterScore } = await chrome.storage.local.get(
        ['enabled', 'vocab', 'activeUser', 'progress', 'lastAskedAt', 'syncMeta', 'usersList', 'wordsPerSession', 'masterScore']
    );
    const MASTER = Math.max(1, masterScore || 2);
    const pool = (vocab && activeUser) ? (vocab[activeUser] || []) : [];
    const p = progress || {};
    const mastered = pool.filter(w => (p[w.id]?.score || 0) >= MASTER).length;
    return {
        enabled: enabled !== false,
        totalWords: pool.length,
        masteredWords: mastered,
        lastAskedAt: lastAskedAt || 0,
        syncMeta: syncMeta || {},
        activeUser: activeUser || null,
        usersList: usersList || [],
        wordsPerSession: wordsPerSession || 2,
        masterScore: MASTER,
    };
}
