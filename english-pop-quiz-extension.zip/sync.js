// Runs on the 4 EnglishApp websites. Reads IndexedDB and ships vocab to extension storage.
(function () {
    const DB_NAME = 'EnglishAppDB';
    const PRIORITY_HOST = 'tuhoctienganh.netlify.app';

    function openDb() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(DB_NAME);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
            req.onblocked = () => reject(new Error('blocked'));
        });
    }

    function getAll(db, store) {
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(store, 'readonly');
                const req = tx.objectStore(store).getAll();
                req.onsuccess = () => resolve(req.result || []);
                req.onerror = () => reject(req.error);
            } catch (e) {
                resolve([]);
            }
        });
    }

    async function sync() {
        try {
            const db = await openDb();
            if (!db.objectStoreNames.contains('vocabulary')) return;
            const vocab = await getAll(db, 'vocabulary');
            if (!vocab.length) return;

            // Also read users table to get display names
            let usersMap = {};
            if (db.objectStoreNames.contains('users')) {
                const users = await getAll(db, 'users');
                users.forEach(u => { if (u.user_code) usersMap[u.user_code] = u.username || u.user_code; });
            }

            // Group all vocab by user_code
            const byUser = {};
            vocab.forEach(w => {
                if (!w.user_code || !w.word || !w.meaning) return;
                if (!byUser[w.user_code]) byUser[w.user_code] = { latest: 0, words: [] };
                const t = new Date(w.created_at || 0).getTime();
                if (t > byUser[w.user_code].latest) byUser[w.user_code].latest = t;
                byUser[w.user_code].words.push({
                    id: w.id,
                    word: w.word,
                    phonetic: w.phonetic || '',
                    meaning: w.meaning || '',
                    pos: extractPos(w.html),
                    sessionName: w.session_name || 'default',
                    sessionCreatedAt: new Date(w.created_at || 0).getTime(),
                });
            });

            if (Object.keys(byUser).length === 0) return;

            // Build user list (for picker)
            const usersList = Object.keys(byUser).map(code => ({
                userCode: code,
                username: usersMap[code] || code,
                wordCount: byUser[code].words.length,
                latest: byUser[code].latest,
            })).sort((a, b) => b.latest - a.latest);

            // Build vocab map
            const vocabMap = {};
            Object.keys(byUser).forEach(code => { vocabMap[code] = byUser[code].words; });

            chrome.runtime.sendMessage({
                type: 'SYNC_VOCAB',
                host: location.hostname,
                priority: location.hostname === PRIORITY_HOST,
                vocabMap,
                usersList,
                syncedAt: Date.now(),
            });
        } catch (e) {
            console.warn('[EnglishPopQuiz] sync failed:', e);
        }
    }

    function extractPos(html) {
        if (!html) return '';
        const m = html.match(/class="type"[^>]*>([^<]*)</);
        return m ? m[1].trim() : '';
    }

    // Run once on load, and again after 3s to catch late DB init
    sync();
    setTimeout(sync, 3000);
})();
